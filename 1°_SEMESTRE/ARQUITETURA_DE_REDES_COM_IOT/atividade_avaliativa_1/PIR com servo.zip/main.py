from utime import sleep
from machine import Pin, PWM, I2C
from picozero import Speaker
from pico_i2c_lcd import I2cLcd

servo = PWM(Pin(21))  # Pino GPIO 15
servo.freq(50)
presenca = Pin(15, Pin.IN)
buzzer = Speaker(18)
led_verd = Pin(16, Pin.OUT)
led_verm = Pin(17, Pin.OUT)
i2c = I2C(1, scl=Pin(19), sda=Pin(18), freq=400000)

I2C_ADDR = i2c.scan()[0]

lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)

while True:
  detectou = presenca.value()
  if detectou == 1:
      print ("Passe!")
      led_verd.on()
      led_verm.off()
      servo.duty_ns(2400000)
      buzzer.on()
      lcd.clear()
      lcd.move_to(1, 0)
      lcd.putstr(f"Passe!")
      sleep(1)

  else:
      detectou == 0
      print ("Pare!")
      led_verm.on()
      led_verd.off()
      servo.duty_ns(1500000)
      buzzer.off()
      lcd.clear()
      lcd.move_to(1, 0)
      lcd.putstr(f"Pare!")
      sleep(1)