from machine import Pin, PWM, ADC
from utime import sleep

led = PWM(Pin(14))
led.freq(1000)
potenciometro = ADC(28)


while True:
  leitura = potenciometro.read_u16 ()
  led.duty_u16(leitura)
  sleep (0.1)