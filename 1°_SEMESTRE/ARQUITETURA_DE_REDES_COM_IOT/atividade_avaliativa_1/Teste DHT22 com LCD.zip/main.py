#sensor porta 15
#led azul porta 20
#led vermelha porta 19
#LCD SDA porta
#LCD SCL porta

from machine import I2C, Pin
from utime import sleep
from dht import DHT22
from pico_i2c_lcd import I2cLcd 

# Configuração dos pinos
sensor = DHT22(Pin(15))
led_vermelho = Pin(19, Pin.OUT)
led_azul = Pin(20, Pin.OUT)

i2c = I2C(0, scl=Pin(17), sda=Pin(16), freq=400000) # Configuração do barramento I2C nos pinos GP16 (SDA) e GP17 (SCL)
I2C_ADDR = i2c.scan()[0] #Descobre o endereço I2C automaticamente (geralmente é 0x27 ou 0x3F)
lcd = I2cLcd(i2c, I2C_ADDR, 2, 16) # Cria o objeto do display LCD com 2 linhas e 16 colunas


while True:
    sensor.measure()
    temp = sensor.temperature()
    umid = sensor.humidity()

    if temp >= 35:
        lcd.clear()
        lcd.putstr(f"A temperatura foi de {temp}°C")
        sleep(2)
        lcd.clear()
        lcd.putstr(f"Está muito calor!")

        led_vermelho.on()
        led_azul.off()
        sleep(0.5)
    
    elif 20 <= temp < 35:
        lcd.clear()
        lcd.putstr(f"A temperatura foi de {temp}°C")
        sleep(2)
        lcd.clear()
        lcd.putstr(f"o clima está ameno...")
        led_vermelho.off()
        led_azul.off()
        sleep(0.5)
    
    else:  # temp < 20
        lcd.clear()
        lcd.putstr(f"A temperatura foi de {temp}°C")
        sleep(2)
        lcd.clear()
        lcd.putstr(f" está muito frio!")
        led_azul.on()
        led_vermelho.off()
        sleep(0.5)

    sleep(1)  # Aguarda 2 segundos antes da próxima leitura