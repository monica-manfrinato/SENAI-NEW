#Se passar de 30 graus ascende o led vermelho, se passar de 
#led azul porta 20
#led vermelha porta 19

'''from machine import Pin
from utime import sleep
from dht import DHT22 

sensor = DHT22(Pin(16))
led_vermelho = Pin(19, Pin.OUT)
led_azul = Pin(20, Pin.OUT)

while True:

    sensor.measure()
    temp = sensor.temperature()
    umid = sensor.humidity()

    if temp >= 35:
        print (f"A temperatura foi de {temp}°C, está muito calor!")
        led_vermelho.on()
        led_azul.off()

    if temp < 35 and temp >=20:
        print (f"A temperatura foi de {temp}°C, o clima está ameno...")
        led_vermelho.off()
        led_azul.off()
    else:
        print (f"A temperatura foi de {temp}°C, está muito frio!")
        led_azul.on()
        led_vermelho.off()'''



from machine import Pin
from utime import sleep
from dht import DHT22 

# Configuração dos pinos
sensor = DHT22(Pin(15))
led_vermelho = Pin(19, Pin.OUT)
led_azul = Pin(20, Pin.OUT)

while True:
    sensor.measure()
    temp = sensor.temperature()
    umid = sensor.humidity()

    if temp >= 35:
        print(f"A temperatura foi de {temp}°C, está muito calor!")
        led_vermelho.on()
        led_azul.off()
        sleep(0.5)
    
    elif 20 <= temp < 35:
        print(f"A temperatura foi de {temp}°C, o clima está ameno...")
        led_vermelho.off()
        led_azul.off()
        sleep(0.5)
    
    else:  # temp < 20
        print(f"A temperatura foi de {temp}°C, está muito frio!")
        led_azul.on()
        led_vermelho.off()
        sleep(0.5)

    sleep(1)  # Aguarda 2 segundos antes da próxima leitura