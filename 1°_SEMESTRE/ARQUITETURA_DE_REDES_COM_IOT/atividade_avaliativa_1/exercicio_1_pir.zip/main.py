'''
Exercício 1 – Detecção de movimento no console

Objetivo: Testar o sensor PIR imprimindo mensagens no terminal quando detectar
movimento.

PIR

Materiais:

1 Sensor PIR
Protoboard
Fios jumper

Conceitos:

Sensor PIR
Solicitação:

Use GP15 como entrada.
Mostrar "Movimento detectado!" ou "Sem movimento".
'''

################################################################################

from machine import Pin
from utime import sleep

presenca = Pin(15, Pin.IN)


while True:
    detectou = presenca.value()
    if detectou == 1:
        print ("Movimento detectado")
    else:
        detectou == 0
        print ("Sem movimento")

    sleep(1)