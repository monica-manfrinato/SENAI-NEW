'''
Exercício 2 – Acionar LED ao detectar movimento

2

Objetivo: Usar LED como sinal visual de detecção.

PIR

Materiais:

1 LED
1 Resistor 220Ω

Solicitação:

Acenda o LED ao detectar movimento.
Apague quando não houver movimento.
'''

################################################################################

from machine import Pin
from utime import sleep

presenca = Pin(15, Pin.IN)
led = Pin(16, Pin.OUT)


while True:
    detectou = presenca.value()
    if detectou == 1:
        print ("Movimento detectado")
        led.on()
    else:
        detectou == 0
        print ("Sem movimento")
        led.off()

    sleep(1)