#led amarelo - porta 16
#led roxo - porta 17
#led azul - porta 18
#potenciometro - porta 28

from machine import Pin, ADC
from utime import sleep

led_amarela = Pin(16,Pin.OUT)
led_roxa = Pin(17,Pin.OUT)
led_azul = Pin(18,Pin.OUT)
potenciometro = ADC(28)


while True:
    leitura = potenciometro.read_u16()
    if leitura <= 10000:
        led_roxa.off()
        led_azul.off()
        led_amarela.on()
        sleep (0.1)

    elif leitura > 10000 and leitura <= 40000:
        led_roxa.on()
        led_azul.off()
        led_amarela.off()
        sleep (0.1)

    elif leitura > 40000:
        led_roxa.off()
        led_azul.on()
        led_amarela.off()
        sleep (0.1)

    