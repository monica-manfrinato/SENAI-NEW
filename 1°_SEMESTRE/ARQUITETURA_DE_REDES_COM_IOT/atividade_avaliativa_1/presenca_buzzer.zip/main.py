from machine import Pin
from utime import sleep
from picozero import Speaker

buzzer = Speaker(16)
presenca = Pin(15, Pin.IN)


while True:
    detectou = presenca.value()
    if detectou == 1:
        buzzer.on()
        print("Detectou")
    else:
        detectou == 0
        buzzer.off()
        print("Não detectou")

    sleep(1)