from machine import Pin
from utime import sleep
led_azul = Pin(16, Pin.OUT)      
led_roxo = Pin(17, Pin.OUT)      

botao = Pin(15, Pin.IN)    

while True:
    
    if botao.value() == 1:
        led_azul.off()
        led_roxo.on()

        sleep(0.1)
    else:
        led_azul.on()
        led_roxo.off()
        sleep(0.1)