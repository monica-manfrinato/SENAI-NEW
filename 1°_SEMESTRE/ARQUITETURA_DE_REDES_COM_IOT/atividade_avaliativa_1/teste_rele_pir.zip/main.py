from machine import Pin
from utime import sleep

relay = Pin(16, Pin.OUT)
presenca = Pin(15, Pin.IN)


while True:
    detectou = presenca.value()
    if detectou == 1:
        relay.on()
        print("Detectou")
    else:
        detectou == 0
        relay.off()
        print("Não detectou")

    sleep(1)
    